package chatapp;

import java.util.*;
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;

public final class Message {
    private static int totalMessages = 0;
    private final String messageID;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random rand = new Random();
        return String.format("%010d", rand.nextInt(1_000_000_000));
    }

    public boolean checkRecipientCell() {
        return recipient.matches("^\\+\\d{1,3}\\d{7,10}$");
    }

    public boolean checkMessageLength() {
        return messageText.length() <= 250;
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : "";
        return (messageID.substring(0, 2) + ":" + totalMessages + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sendMessage() {
        String[] options = {"Send Message", "Store Message", "Disregard Message"};
        int choice = JOptionPane.showOptionDialog(null, "Choose an action:",
                "Message Action", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        switch (choice) {
            case 0 -> {
                totalMessages++;
                return "Message successfully sent.";
            }
            case 1 -> {
                storeMessage();
                return "Message successfully stored.";
            }
            case 2 -> {
                return "Message discarded.";
            }
            default -> {
                return "No action taken.";
            }
        }
    }

    public void storeMessage() {
        JSONObject msgObj = new JSONObject();
        msgObj.put("MessageID", messageID);
        msgObj.put("Recipient", recipient);
        msgObj.put("Message", messageText);
        msgObj.put("Hash", messageHash);

        try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(msgObj.toJSONString() + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing JSON file.");
        }
    }

    public String printMessageDetails() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipient +
                "\nMessage: " + messageText;
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }
}

