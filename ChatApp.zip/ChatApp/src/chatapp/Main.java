package chatapp;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Registration
        String username = JOptionPane.showInputDialog("Register - Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String cellNumber = JOptionPane.showInputDialog("Enter cell number:");

        Login login = new Login(username, password, cellNumber);
        JOptionPane.showMessageDialog(null, login.registerUser());

        if (login.checkUserName() && login.checkPasswordComplexity() && login.checkCellPhoneNumber()) {
            // Login
            String inputUser = JOptionPane.showInputDialog("Login - Enter username:");
            String inputPass = JOptionPane.showInputDialog("Enter password:");

            boolean isLoggedIn = login.loginUser(inputUser, inputPass);
            String firstName = JOptionPane.showInputDialog("Enter first name:");
            String lastName = JOptionPane.showInputDialog("Enter last name:");
            JOptionPane.showMessageDialog(null, login.returnLoginStatus(firstName, lastName, isLoggedIn));

            if (isLoggedIn) {
                JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

                while (true) {
                    String choice = JOptionPane.showInputDialog("""
                            Choose an option:
                            1) Send Messages
                            2) Show Recently Sent Messages
                            3) Quit""");

                    switch (choice) {
                        case "1" -> {
                            int msgCount = Integer.parseInt(JOptionPane.showInputDialog("How many messages to send?"));
                            for (int i = 0; i < msgCount; i++) {
                                String recipient = JOptionPane.showInputDialog("Enter recipient cell number:");
                                String messageText = JOptionPane.showInputDialog("Enter message (max 250 chars):");

                                Message msg = new Message(recipient, messageText);

                                if (!msg.checkRecipientCell()) {
                                    JOptionPane.showMessageDialog(null,
                                            "Cell phone number is incorrectly formatted or does not contain an international code.");
                                    continue;
                                }

                                if (!msg.checkMessageLength()) {
                                    int overBy = messageText.length() - 250;
                                    JOptionPane.showMessageDialog(null,
                                            "Message exceeds 250 characters by " + overBy + ". Please reduce size.");
                                    continue;
                                }

                                String status = msg.sendMessage();
                                JOptionPane.showMessageDialog(null, msg.printMessageDetails() + "\n" + status);
                            }
                            JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());
                        }
                        case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon.");
                        case "3" -> {
                            JOptionPane.showMessageDialog(null, "Thank you for using QuickChat.");
                            return;
                        }
                        default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
                    }
                }
            }
        }
    }
}


