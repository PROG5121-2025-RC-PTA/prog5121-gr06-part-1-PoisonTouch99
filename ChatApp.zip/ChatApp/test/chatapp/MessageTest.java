package chatapp;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class MessageTest {

    @Test
    public void testValidRecipient() {
        Message msg = new Message("+27718693002", "Hello");
        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipient() {
        Message msg = new Message("08575975889", "Hello");
        assertFalse(msg.checkRecipientCell());
    }

    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message("+27123456789", "Short message");
        assertTrue(msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFail() {
        String longMsg = "x".repeat(251);
        Message msg = new Message("+27123456789", longMsg);
        assertFalse(msg.checkMessageLength());
    }

    @Test
    public void testMessageHashFormat() {
        Message msg = new Message("+27123456789", "Hi Mike, can you join us tonight");
        String hash = msg.createMessageHash();
        assertTrue(hash.contains(":"));
    }
}
